import pandas as pd
import time
import string
import re
from collections import Counter
from multiprocessing import Pool, cpu_count
import nltk
from nltk.corpus import stopwords

# Download stopwords if not already downloaded
try:
    stop_words = set(stopwords.words('english'))
except:
    nltk.download('stopwords')
    stop_words = set(stopwords.words('english'))

def clean_text(text):
    """Clean and tokenize text"""
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\d+', '', text)
    words = text.split()
    words = [word for word in words if word not in stop_words and len(word) > 2]
    return words

def process_chunk(chunk_data):
    """Process a chunk of text data"""
    chunk_id, texts = chunk_data
    local_counter = Counter()
    
    for text in texts:
        words = clean_text(str(text))
        local_counter.update(words)
    
    return local_counter

def parallel_analysis(filename, num_rows=20000, num_workers=4):
    """Perform parallel text analysis"""
    print(f"Starting parallel analysis with {num_workers} workers...")
    
    start_time = time.perf_counter()
    
    # Load dataset
    df = pd.read_csv(filename, nrows=num_rows)
    
    # Detect text column
    text_column = None
    for col in ['review', 'review_text', 'text', 'comment', 'content']:
        if col in df.columns:
            text_column = col
            break
    if text_column is None:
        text_column = df.columns[1]
    
    # Extract text data
    texts = df[text_column].tolist()
    
    # Split data into chunks
    chunk_size = len(texts) // num_workers
    chunks = []
    
    for i in range(num_workers):
        start_idx = i * chunk_size
        if i == num_workers - 1:
            end_idx = len(texts)
        else:
            end_idx = (i + 1) * chunk_size
        chunks.append((i, texts[start_idx:end_idx]))
    
    # Process chunks in parallel
    with Pool(processes=num_workers) as pool:
        results = pool.map(process_chunk, chunks)
    
    # Merge results
    final_counter = Counter()
    for counter in results:
        final_counter.update(counter)
    
    end_time = time.perf_counter()
    total_time = end_time - start_time
    
    return total_time, final_counter

def run_scalability_test(filename, num_rows=20000):
    """Run analysis with different numbers of workers"""
    print(f"{'='*70}")
    print(f"PARALLEL TEXT ANALYSIS - SCALABILITY TEST")
    print(f"{'='*70}")
    print(f"Dataset: {filename}")
    print(f"Rows: {num_rows}")
    print(f"\nRunning tests...\n")
    
    # Test configurations
    worker_configs = [1, 2, 4, 8]
    results = []
    
    # Get baseline (sequential time)
    baseline_time = None
    
    for num_workers in worker_configs:
        print(f"Testing with {num_workers} worker(s)...", end=" ")
        
        total_time, word_counts = parallel_analysis(filename, num_rows, num_workers)
        
        if baseline_time is None:
            baseline_time = total_time
            speedup = 1.0
        else:
            speedup = baseline_time / total_time
        
        efficiency = (speedup / num_workers) * 100
        
        results.append({
            'workers': num_workers,
            'time': total_time,
            'speedup': speedup,
            'efficiency': efficiency
        })
        
        print(f"Done! Time: {total_time:.2f}s")
    
    # Print results table
    print(f"\n{'='*70}")
    print(f"PERFORMANCE RESULTS")
    print(f"{'='*70}")
    print(f"{'Workers':<10} | {'Time (s)':<10} | {'Speedup':<10} | {'Efficiency (%)':<15}")
    print(f"{'-'*70}")
    
    for r in results:
        print(f"{r['workers']:<10} | {r['time']:<10.2f} | {r['speedup']:<10.2f}x | {r['efficiency']:<15.1f}")
    
    print(f"{'='*70}")
    
    # Save results to file
    with open('parallel_results.csv', 'w') as f:
        f.write("workers,time_seconds,speedup,efficiency_percent\n")
        for r in results:
            f.write(f"{r['workers']},{r['time']:.2f},{r['speedup']:.2f},{r['efficiency']:.1f}\n")
    
    print(f"\nResults saved to parallel_results.csv")
    
    # Print top words
    print(f"\nTop 20 most frequent words:")
    top_20 = word_counts.most_common(20)
    for i, (word, count) in enumerate(top_20, 1):
        print(f"{i:2d}. {word:15s} : {count:6d}")
    
    # Save top words
    with open('parallel_output.csv', 'w') as f:
        f.write("word,frequency\n")
        for word, count in top_20:
            f.write(f"{word},{count}\n")
    
    return results

if __name__ == "__main__":
    DATASET_FILE = "reviews.csv"
    NUM_ROWS = 20000
    
    run_scalability_test(DATASET_FILE, NUM_ROWS)