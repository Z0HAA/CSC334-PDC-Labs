import pandas as pd
import time
import string
import re
from collections import Counter
import nltk
from nltk.corpus import stopwords

# Download stopwords if not already downloaded
try:
    stop_words = set(stopwords.words('english'))
except:
    nltk.download('stopwords')
    stop_words = set(stopwords.words('english'))

def clean_text(text):
    """Clean and tokenize text"""
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\d+', '', text)
    words = text.split()
    words = [word for word in words if word not in stop_words and len(word) > 2]
    return words

def sequential_analysis(filename, num_rows=20000):
    """Perform sequential text analysis"""
    print(f"Starting sequential text analysis...")
    print(f"Loading {num_rows} rows from dataset...")
    
    start_time = time.perf_counter()

    # Load dataset
    try:
        df = pd.read_csv(filename, nrows=num_rows)
    except Exception as e:
        print(f"Error loading file: {e}")
        return
    
    # Detect text column (common names)
    text_column = None
    for col in ['review', 'review_text', 'text', 'comment', 'content']:
        if col in df.columns:
            text_column = col
            break
    if text_column is None:
        text_column = df.columns[1]  # fallback
    
    print(f"Using column: {text_column}")

    # Process text
    all_words = []
    for i, text in enumerate(df[text_column].astype(str)):
        all_words.extend(clean_text(text))
        if (i + 1) % 5000 == 0:
            print(f"Processed {i + 1} reviews...")

    # Word frequency count
    word_counts = Counter(all_words)
    top_20 = word_counts.most_common(20)

    # Save results
    pd.DataFrame(top_20, columns=["word", "frequency"]).to_csv("seq_output.csv", index=False)

    end_time = time.perf_counter()
    total_time = end_time - start_time

    # Output results
    print("\n==============================================")
    print(f"Processed {len(df)} reviews in {total_time:.2f} seconds.")
    print(f"Top 20 most frequent words:")
    for i, (word, count) in enumerate(top_20, 1):
        print(f"{i:2d}. {word:15s} : {count:6d}")
    print("==============================================")
    print("Results saved to seq_output.csv")

    # 👇 This line is required by Task 1
    print(f"Total processing time: {total_time:.2f} seconds")

    return total_time

if __name__ == "__main__":
    DATASET_FILE = "reviews.csv"   # change if needed
    NUM_ROWS = 20000
    sequential_analysis(DATASET_FILE, NUM_ROWS)
