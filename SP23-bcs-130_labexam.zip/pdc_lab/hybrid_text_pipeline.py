from mpi4py import MPI
import pandas as pd
import time
import string
import re
from collections import Counter
from multiprocessing import Pool
import nltk

try:
    from nltk.corpus import stopwords
    stop_words = set(stopwords.words('english'))
except:
    nltk.download('stopwords')
    from nltk.corpus import stopwords
    stop_words = set(stopwords.words('english'))

def clean_text(text):
    """Clean and tokenize text"""
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\d+', '', text)
    words = text.split()
    words = [word for word in words if word not in stop_words and len(word) > 2]
    return words

def process_sub_chunk(texts):
    """Process a sub-chunk of texts (used by multiprocessing within each MPI node)"""
    local_counter = Counter()
    for text in texts:
        words = clean_text(str(text))
        local_counter.update(words)
    return local_counter

def hybrid_process_chunk(data):
    """
    Process chunk using multiprocessing within the node
    data = (texts, num_local_threads)
    """
    texts, num_local_threads = data
    
    if len(texts) == 0:
        return Counter()
    
    # Split texts into sub-chunks for local parallelism
    sub_chunk_size = max(1, len(texts) // num_local_threads)
    sub_chunks = []
    
    for i in range(num_local_threads):
        start_idx = i * sub_chunk_size
        if i == num_local_threads - 1:
            end_idx = len(texts)
        else:
            end_idx = (i + 1) * sub_chunk_size
        sub_chunks.append(texts[start_idx:end_idx])
    
    # Use multiprocessing to process sub-chunks in parallel
    with Pool(processes=num_local_threads) as pool:
        results = pool.map(process_sub_chunk, sub_chunks)
    
    # Merge local results
    final_counter = Counter()
    for counter in results:
        final_counter.update(counter)
    
    return final_counter

def main_hybrid():
    """Hybrid MPI + Multiprocessing implementation"""
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    # Configuration
    filename = "reviews.csv"
    num_rows = 20000
    num_local_threads = 4  # Number of threads per MPI process
    
    if rank == 0:
        print(f"{'='*70}")
        print(f"HYBRID PARALLEL TEXT ANALYSIS (MPI + Multiprocessing)")
        print(f"{'='*70}")
        print(f"MPI Processes: {size}")
        print(f"Threads per process: {num_local_threads}")
        print(f"Total parallelism: {size * num_local_threads}")
        print(f"Dataset: {filename}")
        print(f"Rows: {num_rows}\n")
        
        overall_start = time.perf_counter()
        
        # Load dataset
        print(f"Node 0: Loading dataset...")
        df = pd.read_csv(filename, nrows=num_rows)
        
        # Detect text column
        text_column = None
        for col in ['review', 'review_text', 'text', 'comment', 'content']:
            if col in df.columns:
                text_column = col
                break
        if text_column is None:
            text_column = df.columns[1]
        
        all_texts = df[text_column].tolist()
        
        # Split into chunks for MPI processes
        chunk_size = len(all_texts) // size
        chunks = []
        
        for i in range(size):
            start_idx = i * chunk_size
            if i == size - 1:
                end_idx = len(all_texts)
            else:
                end_idx = (i + 1) * chunk_size
            chunks.append(all_texts[start_idx:end_idx])
        
        print(f"Node 0: Split data into {size} MPI chunks\n")
    else:
        chunks = None
        overall_start = None
    
    # Scatter data to all MPI processes
    comm_start = time.perf_counter() if rank == 0 else None
    local_texts = comm.scatter(chunks, root=0)
    comm_scatter_time = time.perf_counter() - comm_start if rank == 0 else 0
    
    # Each MPI process uses multiprocessing internally
    node_start = time.perf_counter()
    local_counter = hybrid_process_chunk((local_texts, num_local_threads))
    node_end = time.perf_counter()
    node_time = node_end - node_start
    
    print(f"Node {rank}: Processed {len(local_texts)} reviews in {node_time:.2f}s using {num_local_threads} threads")
    
    # Gather results back to master
    comm_gather_start = time.perf_counter()
    all_counters = comm.gather(local_counter, root=0)
    comm_gather_time = time.perf_counter() - comm_gather_start if rank == 0 else 0
    
    if rank == 0:
        # Merge all counters
        final_counter = Counter()
        for counter in all_counters:
            final_counter.update(counter)
        
        overall_end = time.perf_counter()
        total_time = overall_end - overall_start
        comm_overhead = comm_scatter_time + comm_gather_time
        
        print(f"\n{'='*70}")
        print(f"HYBRID PERFORMANCE SUMMARY")
        print(f"{'='*70}")
        print(f"Communication overhead: {comm_overhead:.2f}s")
        print(f"Hybrid total time: {total_time:.2f}s")
        
        # Estimate sequential time (rough approximation)
        estimated_seq = node_time * size * num_local_threads
        speedup = estimated_seq / total_time
        print(f"Estimated hybrid speedup: {speedup:.2f}x vs Sequential")
        
        # Print top words
        print(f"\n{'='*70}")
        print(f"TOP 20 MOST FREQUENT WORDS")
        print(f"{'='*70}")
        top_20 = final_counter.most_common(20)
        for i, (word, count) in enumerate(top_20, 1):
            print(f"{i:2d}. {word:15s} : {count:6d}")
        
        # Save results
        with open('hybrid_output.csv', 'w') as f:
            f.write("word,frequency\n")
            for word, count in top_20:
                f.write(f"{word},{count}\n")

def main_sentiment_hybrid():
    """Hybrid with sentiment-specific filtering"""
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    if size < 2:
        if rank == 0:
            print("Sentiment filtering requires at least 2 MPI processes")
        return
    
    filename = "reviews.csv"
    num_rows = 20000
    num_local_threads = 4
    
    if rank == 0:
        print(f"\n{'='*70}")
        print(f"HYBRID WITH SENTIMENT-SPECIFIC FILTERING")
        print(f"{'='*70}")
        print(f"Node 0: Positive reviews")
        print(f"Node 1: Negative reviews\n")
        
        overall_start = time.perf_counter()
        
        # Load dataset
        df = pd.read_csv(filename, nrows=num_rows)
        
        # Detect text and sentiment columns
        text_column = None
        for col in ['review', 'review_text', 'text', 'comment', 'content']:
            if col in df.columns:
                text_column = col
                break
        if text_column is None:
            text_column = df.columns[1]
        
        sentiment_column = None
        for col in ['sentiment', 'label', 'rating', 'score']:
            if col in df.columns:
                sentiment_column = col
                break
        
        if sentiment_column is None:
            print("Warning: No sentiment column found, using all data for both nodes")
            positive_texts = df[text_column].tolist()[:len(df)//2]
            negative_texts = df[text_column].tolist()[len(df)//2:]
        else:
            # Filter by sentiment
            positive_texts = df[df[sentiment_column].isin(['positive', 'pos', '1', 1])][text_column].tolist()
            negative_texts = df[df[sentiment_column].isin(['negative', 'neg', '0', 0])][text_column].tolist()
        
        print(f"Positive reviews: {len(positive_texts)}")
        print(f"Negative reviews: {len(negative_texts)}\n")
        
        # Send to nodes
        sentiment_data = [positive_texts, negative_texts] + [[] for _ in range(size - 2)]
    else:
        sentiment_data = None
        overall_start = None
    
    # Scatter sentiment-specific data
    local_texts = comm.scatter(sentiment_data, root=0)
    
    # Process with local parallelism
    node_start = time.perf_counter()
    local_counter = hybrid_process_chunk((local_texts, num_local_threads))
    node_end = time.perf_counter()
    node_time = node_end - node_start
    
    sentiment_type = "positive" if rank == 0 else "negative" if rank == 1 else "none"
    print(f"Node {rank} ({sentiment_type}): processed {len(local_texts)} reviews in {node_time:.2f}s")
    
    # Gather results
    all_counters = comm.gather(local_counter, root=0)
    
    if rank == 0:
        overall_end = time.perf_counter()
        total_time = overall_end - overall_start
        
        print(f"\n{'='*70}")
        print(f"SENTIMENT-SPECIFIC RESULTS")
        print(f"{'='*70}")
        print(f"Total time: {total_time:.2f}s\n")
        
        positive_counter = all_counters[0]
        negative_counter = all_counters[1]
        
        print("Top 10 Positive Sentiment Words:")
        for i, (word, count) in enumerate(positive_counter.most_common(10), 1):
            print(f"{i:2d}. {word:15s} : {count:6d}")
        
        print("\nTop 10 Negative Sentiment Words:")
        for i, (word, count) in enumerate(negative_counter.most_common(10), 1):
            print(f"{i:2d}. {word:15s} : {count:6d}")
        
        # Merge both
        combined_counter = positive_counter + negative_counter
        
        print("\nTop 10 Overall Words:")
        for i, (word, count) in enumerate(combined_counter.most_common(10), 1):
            print(f"{i:2d}. {word:15s} : {count:6d}")

if __name__ == "__main__":
    # Run standard hybrid
    main_hybrid()
    
    # Run sentiment-specific version
    comm = MPI.COMM_WORLD
    if comm.Get_size() >= 2:
        main_sentiment_hybrid()