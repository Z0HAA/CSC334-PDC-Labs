from mpi4py import MPI
import pandas as pd
import time
import string
import re
from collections import Counter
import nltk
import sys

# Download stopwords if not already downloaded
try:
    from nltk.corpus import stopwords
    stop_words = set(stopwords.words('english'))
except:
    nltk.download('stopwords')
    from nltk.corpus import stopwords
    stop_words = set(stopwords.words('english'))

def clean_text(text):
    """Clean and tokenize text"""
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\d+', '', text)
    words = text.split()
    words = [word for word in words if word not in stop_words and len(word) > 2]
    return words

def process_text_chunk(texts):
    """Process a chunk of texts and return word counts"""
    local_counter = Counter()
    
    for text in texts:
        words = clean_text(str(text))
        local_counter.update(words)
    
    return local_counter

def main():
    # Initialize MPI
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    # Parameters
    filename = "reviews.csv"
    num_rows = 20000
    
    # Master process (rank 0)
    if rank == 0:
        print(f"{'='*70}")
        print(f"MPI TEXT ANALYSIS")
        print(f"{'='*70}")
        print(f"Number of MPI processes: {size}")
        print(f"Dataset: {filename}")
        print(f"Rows: {num_rows}\n")
        
        start_time = time.perf_counter()
        
        # Load dataset
        print(f"Rank 0: Loading dataset...")
        df = pd.read_csv(filename, nrows=num_rows)
        
        # Detect text column
        text_column = None
        for col in ['review', 'review_text', 'text', 'comment', 'content']:
            if col in df.columns:
                text_column = col
                break
        if text_column is None:
            text_column = df.columns[1]
        
        print(f"Rank 0: Using column '{text_column}'")
        
        # Extract texts
        all_texts = df[text_column].tolist()
        total_texts = len(all_texts)
        
        # Split data into chunks for each rank
        chunk_size = total_texts // size
        chunks = []
        
        for i in range(size):
            start_idx = i * chunk_size
            if i == size - 1:
                end_idx = total_texts
            else:
                end_idx = (i + 1) * chunk_size
            chunks.append(all_texts[start_idx:end_idx])
        
        print(f"Rank 0: Split data into {size} chunks")
        print(f"Rank 0: Chunk sizes: {[len(c) for c in chunks]}\n")
        
    else:
        chunks = None
        start_time = None
    
    # Scatter data to all processes
    local_chunk = comm.scatter(chunks, root=0)
    
    # Each process times its own work
    local_start = time.perf_counter()
    
    # Process local chunk
    local_counter = process_text_chunk(local_chunk)
    
    local_end = time.perf_counter()
    local_time = local_end - local_start
    
    # Print local results
    print(f"Rank {rank} processed {len(local_chunk)} lines in {local_time:.2f}s")
    
    # Gather all counters to master
    all_counters = comm.gather(local_counter, root=0)
    
    # Master aggregates results
    if rank == 0:
        print(f"\n{'='*70}")
        print(f"AGGREGATING RESULTS")
        print(f"{'='*70}")
        
        # Merge all counters
        final_counter = Counter()
        for counter in all_counters:
            final_counter.update(counter)
        
        end_time = time.perf_counter()
        total_time = end_time - start_time
        
        print(f"Total distributed time: {total_time:.2f}s")
        
        # Compare with estimated sequential time
        # Rough estimate based on processing time
        max_local_time = max([c.result() if hasattr(c, 'result') else local_time for c in [local_time]])
        estimated_sequential = max_local_time * size
        speedup = estimated_sequential / total_time
        
        print(f"Estimated speedup: {speedup:.2f}x")
        
        # Print top 20 words
        print(f"\n{'='*70}")
        print(f"TOP 20 MOST FREQUENT WORDS")
        print(f"{'='*70}")
        
        top_20 = final_counter.most_common(20)
        for i, (word, count) in enumerate(top_20, 1):
            print(f"{i:2d}. {word:15s} : {count:6d}")
        
        # Save results
        with open('mpi_output.csv', 'w') as f:
            f.write("word,frequency\n")
            for word, count in top_20:
                f.write(f"{word},{count}\n")
        
        print(f"\n{'='*70}")
        print(f"Results saved to mpi_output.csv")
        print(f"{'='*70}")

def main_with_imbalance():
    """Version with intentional load imbalance"""
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    filename = "reviews.csv"
    num_rows = 20000
    
    if rank == 0:
        print(f"\n{'='*70}")
        print(f"MPI TEXT ANALYSIS - WITH LOAD IMBALANCE")
        print(f"{'='*70}")
        print(f"Number of MPI processes: {size}\n")
        
        start_time = time.perf_counter()
        
        # Load dataset
        df = pd.read_csv(filename, nrows=num_rows)
        
        text_column = None
        for col in ['review', 'review_text', 'text', 'comment', 'content']:
            if col in df.columns:
                text_column = col
                break
        if text_column is None:
            text_column = df.columns[1]
        
        all_texts = df[text_column].tolist()
        total_texts = len(all_texts)
        
        # Create imbalanced chunks - rank 0 gets 50% more data
        chunks = []
        base_size = total_texts // (size + 0.5)  # Adjusted for imbalance
        
        # Rank 0 gets 1.5x the base size
        chunks.append(all_texts[0:int(base_size * 1.5)])
        
        # Remaining ranks split the rest
        remaining = all_texts[int(base_size * 1.5):]
        remaining_size = len(remaining) // (size - 1) if size > 1 else len(remaining)
        
        for i in range(1, size):
            start_idx = (i - 1) * remaining_size
            if i == size - 1:
                end_idx = len(remaining)
            else:
                end_idx = i * remaining_size
            chunks.append(remaining[start_idx:end_idx])
        
        print(f"Imbalanced chunk sizes: {[len(c) for c in chunks]}")
        print(f"Rank 0 has {(len(chunks[0]) / base_size - 1) * 100:.0f}% more data\n")
    else:
        chunks = None
        start_time = None
    
    local_chunk = comm.scatter(chunks, root=0)
    local_start = time.perf_counter()
    local_counter = process_text_chunk(local_chunk)
    local_end = time.perf_counter()
    local_time = local_end - local_start
    
    print(f"Rank {rank} processed {len(local_chunk)} lines in {local_time:.2f}s")
    
    all_counters = comm.gather(local_counter, root=0)
    
    if rank == 0:
        final_counter = Counter()
        for counter in all_counters:
            final_counter.update(counter)
        
        end_time = time.perf_counter()
        total_time = end_time - start_time
        
        print(f"\nTotal time with imbalance: {total_time:.2f}s")
        print(f"Notice: The slowest rank determines total execution time!")

if __name__ == "__main__":
    # Run balanced version
    main()
    
    # Run imbalanced version if size > 1
    comm = MPI.COMM_WORLD
    if comm.Get_size() > 1:
        main_with_imbalance()